package "mysql-server" do
  action :purge
end

case node[:platform]
when "ubuntu"
	package "mysql-client" do
	  action :purge
	end

	execute "request percona key" do
	  command "gpg --keyserver subkeys.pgp.net --recv-keys 1C4CBDCDCD2EFD2A"
	  not_if "gpg --list-keys CD2EFD2A"
	end

	execute "install percona key" do
	  command "gpg -a --export CD2EFD2A | apt-key add -"
	  not_if "apt-key list | grep CD2EFD2A"
	end

	execute "apt-get update" do
	  action :nothing
	end

	cookbook_file "/etc/apt/sources.list.d/percona.list" do
	  source "percona.list"
          mode "0644"
	  notifies :run, resources("execute[apt-get update]"), :immediately
	end
	

	package "percona-server-server" do
	  action :install
	  options "--no-install-recommends"
	end

	package "percona-server-client"

when "redhat","centos"
	package "mysql" do
	  action :purge
	end

	if node[:kernel][:machine] == "i686"
  		arch = "i386"
	else
  		arch = node[:kernel][:machine]
	end

	execute "rpm -Uvh --replacepkgs http://www.percona.com/downloads/percona-release/percona-release-0.0-1.#{arch}.rpm"

	ruby_block "clean_yum_cache" do
          block do
            yum = Chef::Provider::Package::Yum::YumCache.instance
            yum.load_data
          end
          action :create
        end

	package "Percona-Server-server-51"
	package "Percona-Server-client-51"

	execute "cp /usr/share/mysql/my-medium.cnf /etc/my.cnf"
end

service "mysql" do
	action [ :disable, :stop ]
end
